export type SearchResult = { title: string; snippet: string; url: string };

export async function freeWebSearch(query: string): Promise<SearchResult[]> {
  try {
    const r = await fetch("/api/websearch?q=" + encodeURIComponent(query));
    if (!r.ok) return [];
    const j = (await r.json()) as { results?: SearchResult[] };
    return j.results ?? [];
  } catch {
    return [];
  }
}

function sanitize(s: string): string {
  return (s || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => {
      try {
        return String.fromCodePoint(parseInt(h, 16));
      } catch {
        return "";
      }
    })
    .replace(/&#(\d+);/g, (_, d) => {
      try {
        return String.fromCodePoint(parseInt(d, 10));
      } catch {
        return "";
      }
    })
    .split("")
    .filter((ch) => {
      const code = ch.charCodeAt(0);
      return !(
        code <= 31 ||
        (code >= 127 && code <= 159) ||
        (code >= 8203 && code <= 8207) ||
        code === 65279
      );
    })
    .join("")
    .replace(/https?:\/\/\S+/g, "")
    .replace(/\\+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function buildLiveContext(query: string, results: SearchResult[]): string {
  const guard =
    "Current year is 2026. Treat any scraped dates before 2026 as archival context only; never describe older events as upcoming, new, recently released, or current.";
  if (!results.length) {
    return `Use this verified 2026 current web data to answer the user: ${guard} No live results available for "${sanitize(query)}" — answer from best knowledge and acknowledge the gap.`;
  }
  const lines = results
    .slice(0, 3)
    .map((r) => {
      const title = sanitize(r.title);
      const snippet = sanitize(r.snippet).slice(0, 240);
      return `${title} - ${snippet}`;
    })
    .filter((l) => l.replace(/[-\s]/g, "").length > 0);
  return `Use this verified 2026 current web data to answer the user: ${guard} Cleaned snippets: ${lines.join(" | ")}`;
}
